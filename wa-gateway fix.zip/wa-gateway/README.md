# 📱 WA Gateway — WhatsApp Notification API

Self-hosted WhatsApp API Gateway menggunakan **Baileys** (unofficial library).
Cocok untuk kirim notifikasi, OTP, alert, dan broadcast message.

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
# Masuk ke folder project
cd wa-gateway

# Copy environment file
cp .env.example .env

# Edit API key (opsional tapi sangat dianjurkan untuk production)
nano .env

# Install dependencies
npm install
```

### 2. Jalankan Server

```bash
npm start
```

### 3. Login WhatsApp

Buka browser → `http://localhost:3000`

Dashboard akan menampilkan QR code. Scan dengan WhatsApp:
- Buka WhatsApp di HP
- Ketuk ⋮ (menu) → **Perangkat Tertaut** → **Tautkan Perangkat**
- Scan QR

Setelah terhubung, status akan berubah menjadi **CONNECTED** ✅

---

## 📡 API Reference

Semua endpoint memerlukan header `X-Api-Key` jika `API_KEY` sudah diset di `.env`.

### Kirim Pesan Teks

```bash
POST /api/send/text
Content-Type: application/json
X-Api-Key: your-secret-api-key-here

{
  "to": "6281234567890",
  "message": "Halo dari WA Gateway! 👋"
}
```

**Response:**
```json
{
  "ok": true,
  "jobId": "uuid-xxx",
  "status": "pending"
}
```

---

### Kirim Gambar

```bash
POST /api/send/image

{
  "to": "6281234567890",
  "imageUrl": "https://example.com/foto.jpg",
  "caption": "Ini caption gambar (opsional)"
}
```

---

### Kirim Dokumen / File

```bash
POST /api/send/document

{
  "to": "6281234567890",
  "fileUrl": "https://example.com/laporan.pdf",
  "fileName": "laporan-bulanan.pdf",
  "mimetype": "application/pdf"
}
```

---

### Blast Pesan ke Banyak Nomor

```bash
POST /api/send/bulk

{
  "recipients": ["6281234567890", "6289876543210", "6285555555555"],
  "message": "Promo spesial hari ini! Diskon 50% 🎉"
}
```

> Maksimal 100 nomor per request. Pesan dikirim antri agar tidak di-ban WA.

---

### Cek Status Pengiriman

```bash
GET /api/jobs/{jobId}
```

**Response:**
```json
{
  "ok": true,
  "job": {
    "id": "uuid-xxx",
    "type": "text",
    "status": "sent",   // pending | processing | sent | failed
    "sentAt": "2024-01-15T10:30:00.000Z",
    "result": {
      "messageId": "3EB0...",
      "to": "6281234567890@s.whatsapp.net"
    }
  }
}
```

---

### Status Koneksi

```bash
GET /api/status
```

```json
{
  "ok": true,
  "status": "connected",
  "hasQr": false,
  "retryCount": 0,
  "connectedNumber": "6281234567890@s.whatsapp.net"
}
```

---

### Statistik Queue

```bash
GET /api/jobs/stats
```

```json
{
  "ok": true,
  "stats": {
    "sent": 142,
    "failed": 2,
    "queued": 5,
    "pendingJobs": 3,
    "processingJobs": 1
  }
}
```

---

### Logout

```bash
POST /api/logout
```

Menghapus sesi. Setelah ini, restart server dan scan QR lagi.

---

## ⚙️ Konfigurasi (.env)

| Variable | Default | Keterangan |
|---|---|---|
| `PORT` | `3000` | Port server |
| `API_KEY` | _(kosong)_ | API key untuk autentikasi |
| `RATE_LIMIT_MAX_REQUESTS` | `100` | Max request per menit |
| `QUEUE_CONCURRENCY` | `5` | Pesan paralel yang dikirim |
| `QUEUE_INTERVAL_MS` | `1000` | Jeda antar pesan (ms) — jangan terlalu cepat! |
| `SESSION_DIR` | `./sessions` | Lokasi simpan sesi WA |

---

## 🔌 Integrasi dengan Aplikasi Lain

### Node.js

```js
const response = await fetch('http://localhost:3000/api/send/text', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-Api-Key': 'your-secret-api-key-here'
  },
  body: JSON.stringify({
    to: '6281234567890',
    message: 'Notifikasi dari sistem kami!'
  })
});
const data = await response.json();
console.log(data.jobId); // gunakan ini untuk cek status
```

### PHP

```php
$ch = curl_init('http://localhost:3000/api/send/text');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'X-Api-Key: your-secret-api-key-here'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'to' => '6281234567890',
    'message' => 'Halo dari PHP!'
]));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = json_decode(curl_exec($ch), true);
```

### Python

```python
import requests

res = requests.post('http://localhost:3000/api/send/text',
    json={'to': '6281234567890', 'message': 'Hello from Python!'},
    headers={'X-Api-Key': 'your-secret-api-key-here'}
)
print(res.json())
```

### cURL

```bash
curl -X POST http://localhost:3000/api/send/text \
  -H "Content-Type: application/json" \
  -H "X-Api-Key: your-secret-api-key-here" \
  -d '{"to":"6281234567890","message":"Test message"}'
```

---

## 🌐 Deploy ke VPS dengan Domain (Nginx + SSL)

Agar bisa diakses via `https://yourdomain.com` tanpa port:

### Cara Cepat (1 perintah)

```bash
# Upload folder wa-gateway ke VPS, lalu:
cd /path/to/wa-gateway
bash deploy.sh yourdomain.com email@kamu.com
```

Script ini otomatis:
- Install Node.js, Nginx, Certbot
- Deploy app ke `/var/www/wa-gateway`
- Buat systemd service (auto-start saat reboot)
- Setup Nginx sebagai reverse proxy
- Install SSL gratis via Let's Encrypt

Setelah selesai, langsung buka `https://yourdomain.com` dan scan QR.

### Manual Step-by-Step

```bash
# 1. Install Nginx & Certbot
sudo apt install nginx certbot python3-certbot-nginx -y

# 2. Copy Nginx config
sudo cp nginx.conf /etc/nginx/sites-available/wa-gateway
sudo sed -i "s/yourdomain.com/DOMAIN_KAMU.com/g" /etc/nginx/sites-available/wa-gateway
sudo ln -s /etc/nginx/sites-available/wa-gateway /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# 3. Install SSL
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# 4. Setup systemd service
sudo cp wa-gateway.service /etc/systemd/system/
sudo systemctl enable --now wa-gateway
```

### Syarat
- VPS Ubuntu/Debian dengan IP publik
- Domain sudah diarahkan ke IP VPS (DNS A record)
- Port 80 dan 443 terbuka di firewall

---

## 🐳 Deploy dengan Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .
VOLUME ["/app/sessions"]
EXPOSE 3000
CMD ["node", "src/index.js"]
```

```bash
# Build & run
docker build -t wa-gateway .
docker run -d \
  -p 3000:3000 \
  -v $(pwd)/sessions:/app/sessions \
  --env-file .env \
  --name wa-gateway \
  wa-gateway
```

---

## ⚠️ Penting

- **Ini library unofficial** — tidak ada garansi dari Meta/WhatsApp
- Jangan kirim spam! WA bisa ban nomor jika terlalu agresif
- `QUEUE_INTERVAL_MS` minimal `1000ms` (1 detik) antar pesan
- Session tersimpan di folder `./sessions` — backup folder ini
- Jika nomor di-ban, perlu ganti nomor WA

---

## 📁 Struktur Project

```
wa-gateway/
├── src/
│   ├── index.js          # Entry point, Express app, dashboard
│   ├── whatsapp.js       # Baileys WA client
│   ├── queue.js          # Message queue dengan rate limiting
│   ├── routes.js         # REST API endpoints
│   └── middleware/
│       └── auth.js       # API key authentication
├── sessions/             # WA session (auto-created, jangan hapus)
├── logs/                 # Log files
├── .env.example          # Template konfigurasi
├── package.json
└── README.md
```
