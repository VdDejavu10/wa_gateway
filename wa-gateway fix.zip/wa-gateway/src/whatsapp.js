// src/whatsapp.js
// WhatsApp connection manager using Baileys

const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  isJidBroadcast,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const path = require('path');
const { EventEmitter } = require('events');

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });
const waLogger = logger.child({}, { level: 'silent' }); // suppress Baileys internal logs

class WhatsAppClient extends EventEmitter {
  constructor(sessionDir) {
    super();
    this.sessionDir = sessionDir || './sessions';
    this.sock = null;
    this.qrCode = null;
    this.status = 'disconnected'; // disconnected | connecting | qr_ready | connected
    this.retryCount = 0;
    this.maxRetries = 5;
  }

  async connect() {
    try {
      this.status = 'connecting';
      this.emit('status', this.status);

      const { version } = await fetchLatestBaileysVersion();
      logger.info(`Using WA v${version.join('.')}`);

      const { state, saveCreds } = await useMultiFileAuthState(
        path.resolve(this.sessionDir)
      );

      this.sock = makeWASocket({
        version,
        logger: waLogger,
        printQRInTerminal: true,
        auth: {
          creds: state.creds,
          keys: makeCacheableSignalKeyStore(state.keys, waLogger),
        },
        getMessage: async () => ({ conversation: '' }),
        generateHighQualityLinkPreview: false,
        syncFullHistory: false,
      });

      // Handle credential updates (save session)
      this.sock.ev.on('creds.update', saveCreds);

      // Handle connection updates
      this.sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
          this.qrCode = qr;
          this.status = 'qr_ready';
          this.emit('qr', qr);
          this.emit('status', this.status);
          logger.info('QR Code generated — scan with WhatsApp');
        }

        if (connection === 'open') {
          this.qrCode = null;
          this.status = 'connected';
          this.retryCount = 0;
          this.emit('ready');
          this.emit('status', this.status);
          logger.info('✅ WhatsApp connected!');
        }

        if (connection === 'close') {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

          this.status = 'disconnected';
          this.emit('status', this.status);
          logger.warn({ statusCode }, 'Connection closed');

          if (shouldReconnect && this.retryCount < this.maxRetries) {
            this.retryCount++;
            const delay = Math.min(1000 * 2 ** this.retryCount, 30000);
            logger.info(`Reconnecting in ${delay}ms (attempt ${this.retryCount}/${this.maxRetries})`);
            setTimeout(() => this.connect(), delay);
          } else if (statusCode === DisconnectReason.loggedOut) {
            logger.error('Logged out — delete session folder and restart');
            this.emit('logout');
          } else {
            logger.error('Max retries reached');
            this.emit('error', new Error('Max reconnection attempts reached'));
          }
        }
      });

    } catch (err) {
      logger.error(err, 'Failed to initialize WhatsApp');
      this.status = 'disconnected';
      throw err;
    }
  }

  /**
   * Send a text message
   * @param {string} to - Phone number with country code (e.g., "6281234567890")
   * @param {string} text - Message body
   */
  async sendText(to, text) {
    this._ensureConnected();
    const jid = this._normalizeJid(to);
    const result = await this.sock.sendMessage(jid, { text });
    return { messageId: result.key.id, to: jid };
  }

  /**
   * Send an image with optional caption
   * @param {string} to - Phone number
   * @param {string} imageUrl - Public URL of the image
   * @param {string} caption - Optional caption
   */
  async sendImage(to, imageUrl, caption = '') {
    this._ensureConnected();
    const jid = this._normalizeJid(to);
    const result = await this.sock.sendMessage(jid, {
      image: { url: imageUrl },
      caption,
    });
    return { messageId: result.key.id, to: jid };
  }

  /**
   * Send a document/file
   * @param {string} to - Phone number
   * @param {string} fileUrl - Public URL of the file
   * @param {string} fileName - Display filename
   * @param {string} mimetype - MIME type
   */
  async sendDocument(to, fileUrl, fileName, mimetype = 'application/octet-stream') {
    this._ensureConnected();
    const jid = this._normalizeJid(to);
    const result = await this.sock.sendMessage(jid, {
      document: { url: fileUrl },
      fileName,
      mimetype,
    });
    return { messageId: result.key.id, to: jid };
  }

  getStatus() {
    return {
      status: this.status,
      hasQr: !!this.qrCode,
      retryCount: this.retryCount,
      connectedNumber: this.sock?.user?.id || null,
    };
  }

  getQr() {
    return this.qrCode;
  }

  async logout() {
    if (this.sock) {
      await this.sock.logout();
    }
  }

  _ensureConnected() {
    if (this.status !== 'connected') {
      const err = new Error(`WhatsApp not connected (status: ${this.status})`);
      err.code = 'NOT_CONNECTED';
      throw err;
    }
  }

  _normalizeJid(phone) {
    // Remove non-numeric chars, ensure @s.whatsapp.net suffix
    const clean = phone.toString().replace(/\D/g, '');
    return clean.includes('@') ? clean : `${clean}@s.whatsapp.net`;
  }
}

module.exports = WhatsAppClient;
