// src/index.js
// WA Gateway — main entry point

require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const WhatsAppClient = require('./whatsapp');
const MessageQueue = require('./queue');
const createRouter = require('./routes');
const apiKeyAuth = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

// ─── Security middleware ───────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false })); // CSP off for inline dashboard
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

// Rate limiter
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 60_000,
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many requests — slow down' },
});
app.use('/api', limiter);

// ─── WhatsApp client + queue ───────────────────────────────────────────────
const waClient = new WhatsAppClient(
  path.resolve(process.env.SESSION_DIR || './sessions')
);
const queue = new MessageQueue(waClient, {
  concurrency: parseInt(process.env.QUEUE_CONCURRENCY) || 5,
  intervalMs: parseInt(process.env.QUEUE_INTERVAL_MS) || 1000,
});

// ─── API routes ────────────────────────────────────────────────────────────
app.use('/api', apiKeyAuth, createRouter(waClient, queue));

// ─── Built-in web dashboard ────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.send(getDashboardHTML());
});

// ─── 404 handler ──────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ ok: false, error: `Route ${req.method} ${req.path} not found` });
});

// ─── Error handler ─────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ ok: false, error: 'Internal server error', detail: err.message });
});

// ─── Boot ──────────────────────────────────────────────────────────────────
async function start() {
  console.log('🚀 Starting WA Gateway...');

  waClient.on('status', (s) => console.log(`[WA] Status: ${s}`));
  waClient.on('qr', () => console.log('[WA] QR ready — open http://localhost:' + PORT + ' to scan'));
  waClient.on('ready', () => console.log('[WA] ✅ Connected!'));
  waClient.on('logout', () => console.log('[WA] ❌ Logged out — delete ./sessions and restart'));

  await waClient.connect();

  app.listen(PORT, HOST, () => {
    console.log(`\n📡 WA Gateway running at http://${HOST}:${PORT}`);
    console.log(`   Dashboard : http://localhost:${PORT}`);
    console.log(`   API base  : http://localhost:${PORT}/api`);
    console.log(`   API docs  : http://localhost:${PORT}/api/health\n`);
  });
}

start().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});

// ─── Graceful shutdown ─────────────────────────────────────────────────────
process.on('SIGINT', async () => {
  console.log('\nShutting down...');
  process.exit(0);
});

// ─── Dashboard HTML ────────────────────────────────────────────────────────
function getDashboardHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WA Gateway</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg: #0d1117;
      --surface: #161b22;
      --border: #30363d;
      --green: #25D366;
      --green-dim: #1a9e4b;
      --text: #e6edf3;
      --muted: #7d8590;
      --red: #f85149;
      --yellow: #d29922;
      --font: 'SF Mono', 'Fira Code', monospace;
    }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      min-height: 100vh;
    }

    header {
      border-bottom: 1px solid var(--border);
      padding: 16px 32px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .logo { font-size: 22px; }
    header h1 { font-size: 16px; font-weight: 600; letter-spacing: 0.5px; }
    header span { color: var(--muted); font-size: 13px; }

    .status-pill {
      margin-left: auto;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .pill-connected { background: rgba(37,211,102,0.15); color: var(--green); }
    .pill-qr { background: rgba(210,153,34,0.15); color: var(--yellow); }
    .pill-disconnected { background: rgba(248,81,73,0.15); color: var(--red); }
    .pill-connecting { background: rgba(125,133,144,0.15); color: var(--muted); }

    main { max-width: 960px; margin: 0 auto; padding: 32px; }

    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; }

    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 20px;
    }
    .card h2 { font-size: 13px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 16px; }

    .stat { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .stat-label { color: var(--muted); font-size: 13px; }
    .stat-value { font-size: 14px; font-weight: 600; font-family: var(--font); }
    .v-green { color: var(--green); }
    .v-red { color: var(--red); }
    .v-yellow { color: var(--yellow); }

    #qr-section { text-align: center; }
    #qr-img { width: 200px; height: 200px; border-radius: 8px; border: 3px solid var(--green); margin: 12px auto; display: block; }
    #qr-section p { font-size: 13px; color: var(--muted); }

    .form-card { grid-column: span 2; }
    .form-row { display: grid; grid-template-columns: 1fr 2fr; gap: 12px; margin-bottom: 12px; align-items: center; }
    label { font-size: 13px; color: var(--muted); }
    input, textarea {
      background: var(--bg);
      border: 1px solid var(--border);
      border-radius: 6px;
      color: var(--text);
      padding: 8px 12px;
      font-size: 14px;
      width: 100%;
      font-family: inherit;
    }
    input:focus, textarea:focus { outline: none; border-color: var(--green); }
    textarea { resize: vertical; min-height: 80px; }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: var(--green);
      color: #000;
      border: none;
      border-radius: 6px;
      padding: 10px 20px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.15s;
    }
    .btn:hover { background: var(--green-dim); }
    .btn:disabled { opacity: 0.4; cursor: not-allowed; }

    #result {
      margin-top: 12px;
      padding: 12px;
      border-radius: 6px;
      font-size: 13px;
      font-family: var(--font);
      white-space: pre-wrap;
      display: none;
    }
    #result.success { background: rgba(37,211,102,0.08); border: 1px solid rgba(37,211,102,0.3); color: var(--green); }
    #result.error { background: rgba(248,81,73,0.08); border: 1px solid rgba(248,81,73,0.3); color: var(--red); }

    .endpoints { grid-column: span 2; }
    .endpoint { display: flex; align-items: flex-start; gap: 12px; padding: 10px 0; border-bottom: 1px solid var(--border); }
    .endpoint:last-child { border: none; }
    .method { font-size: 11px; font-weight: 700; font-family: var(--font); padding: 2px 6px; border-radius: 4px; flex-shrink: 0; margin-top: 2px; }
    .m-get { background: rgba(37,211,102,0.1); color: var(--green); }
    .m-post { background: rgba(56,139,253,0.1); color: #58a6ff; }
    .path { font-size: 13px; font-family: var(--font); color: var(--text); }
    .desc { font-size: 12px; color: var(--muted); margin-top: 2px; }

    @media (max-width: 600px) {
      .grid { grid-template-columns: 1fr; }
      .form-card, .endpoints { grid-column: span 1; }
      main { padding: 16px; }
    }
  </style>
</head>
<body>
  <header>
    <span class="logo">📱</span>
    <div>
      <h1>WA Gateway</h1>
      <span>WhatsApp Notification API</span>
    </div>
    <div id="status-pill" class="status-pill pill-connecting">Connecting…</div>
  </header>

  <main>
    <div class="grid">
      <!-- Connection Stats -->
      <div class="card">
        <h2>Connection</h2>
        <div class="stat"><span class="stat-label">Status</span><span id="conn-status" class="stat-value">—</span></div>
        <div class="stat"><span class="stat-label">Number</span><span id="conn-number" class="stat-value v-green">—</span></div>
        <div class="stat"><span class="stat-label">Retries</span><span id="conn-retries" class="stat-value">—</span></div>
      </div>

      <!-- Queue Stats -->
      <div class="card">
        <h2>Queue Stats</h2>
        <div class="stat"><span class="stat-label">Sent</span><span id="q-sent" class="stat-value v-green">—</span></div>
        <div class="stat"><span class="stat-label">Pending</span><span id="q-pending" class="stat-value v-yellow">—</span></div>
        <div class="stat"><span class="stat-label">Failed</span><span id="q-failed" class="stat-value v-red">—</span></div>
      </div>

      <!-- QR Code -->
      <div class="card" id="qr-section" style="display:none;">
        <h2>Scan QR Code</h2>
        <img id="qr-img" src="" alt="QR Code" />
        <p>Open WhatsApp → Linked Devices → Link a Device</p>
      </div>

      <!-- Send Message Form -->
      <div class="card form-card">
        <h2>Send Test Message</h2>
        <div class="form-row">
          <label for="f-to">To (number)</label>
          <input id="f-to" type="text" placeholder="6281234567890" />
        </div>
        <div class="form-row">
          <label for="f-msg">Message</label>
          <textarea id="f-msg" placeholder="Hello from WA Gateway! 👋"></textarea>
        </div>
        <div class="form-row">
          <label for="f-key">API Key</label>
          <input id="f-key" type="password" placeholder="optional if not set" />
        </div>
        <button class="btn" id="send-btn" onclick="sendMessage()">
          <span>▶</span> Send Message
        </button>
        <div id="result"></div>
      </div>

      <!-- API Reference -->
      <div class="card endpoints">
        <h2>API Endpoints</h2>
        <div class="endpoint">
          <span class="method m-get">GET</span>
          <div><div class="path">/api/status</div><div class="desc">Connection status & connected number</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-get">GET</span>
          <div><div class="path">/api/qr</div><div class="desc">Get QR code as base64 PNG (when disconnected)</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-post">POST</span>
          <div><div class="path">/api/send/text</div><div class="desc">Send text message — body: { to, message }</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-post">POST</span>
          <div><div class="path">/api/send/bulk</div><div class="desc">Blast to multiple numbers — body: { recipients[], message }</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-post">POST</span>
          <div><div class="path">/api/send/image</div><div class="desc">Send image — body: { to, imageUrl, caption }</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-post">POST</span>
          <div><div class="path">/api/send/document</div><div class="desc">Send file — body: { to, fileUrl, fileName, mimetype }</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-get">GET</span>
          <div><div class="path">/api/jobs/:id</div><div class="desc">Check delivery status of a queued message</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-get">GET</span>
          <div><div class="path">/api/jobs/stats</div><div class="desc">Queue statistics (sent, failed, pending)</div></div>
        </div>
        <div class="endpoint">
          <span class="method m-post">POST</span>
          <div><div class="path">/api/logout</div><div class="desc">Disconnect & clear session</div></div>
        </div>
      </div>
    </div>
  </main>

  <script>
    let currentStatus = '';

    async function poll() {
      try {
        const [statusRes, statsRes] = await Promise.all([
          fetch('/api/status').then(r => r.json()),
          fetch('/api/jobs/stats').then(r => r.json()),
        ]);

        // Update status pill
        const s = statusRes.status;
        if (s !== currentStatus) {
          currentStatus = s;
          const pill = document.getElementById('status-pill');
          pill.className = 'status-pill pill-' + s.replace('_', '-');
          pill.textContent = s.replace('_', ' ').toUpperCase();
        }

        document.getElementById('conn-status').textContent = statusRes.status;
        document.getElementById('conn-number').textContent = statusRes.connectedNumber || '—';
        document.getElementById('conn-retries').textContent = statusRes.retryCount;

        // Queue stats
        if (statsRes.ok) {
          document.getElementById('q-sent').textContent = statsRes.stats.sent;
          document.getElementById('q-pending').textContent = statsRes.stats.pendingJobs;
          document.getElementById('q-failed').textContent = statsRes.stats.failed;
        }

        // QR code
        const qrSection = document.getElementById('qr-section');
        if (statusRes.hasQr) {
          qrSection.style.display = 'block';
          const qrRes = await fetch('/api/qr').then(r => r.json());
          if (qrRes.ok) document.getElementById('qr-img').src = qrRes.qr;
        } else {
          qrSection.style.display = 'none';
        }
      } catch (e) {
        console.error('Poll error:', e);
      }
    }

    async function sendMessage() {
      const to = document.getElementById('f-to').value.trim();
      const message = document.getElementById('f-msg').value.trim();
      const apiKey = document.getElementById('f-key').value.trim();
      const btn = document.getElementById('send-btn');
      const result = document.getElementById('result');

      if (!to || !message) {
        result.className = 'error';
        result.style.display = 'block';
        result.textContent = 'Fill in both "To" and "Message" fields.';
        return;
      }

      btn.disabled = true;
      btn.textContent = 'Sending…';

      try {
        const headers = { 'Content-Type': 'application/json' };
        if (apiKey) headers['X-Api-Key'] = apiKey;

        const res = await fetch('/api/send/text', {
          method: 'POST',
          headers,
          body: JSON.stringify({ to, message }),
        });
        const data = await res.json();

        result.style.display = 'block';
        if (data.ok) {
          result.className = 'success';
          result.textContent = JSON.stringify(data, null, 2);
        } else {
          result.className = 'error';
          result.textContent = data.error || JSON.stringify(data);
        }
      } catch (e) {
        result.className = 'error';
        result.style.display = 'block';
        result.textContent = 'Request failed: ' + e.message;
      } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>▶</span> Send Message';
      }
    }

    poll();
    setInterval(poll, 3000);
  </script>
</body>
</html>`;
}
