// src/queue.js
// Message queue with rate limiting to avoid WA bans

const { v4: uuidv4 } = require('uuid');

class MessageQueue {
  constructor(waClient, options = {}) {
    this.waClient = waClient;
    this.concurrency = options.concurrency || 5;
    this.intervalMs = options.intervalMs || 1000; // min delay between messages
    this.queue = [];
    this.processing = false;
    this.stats = {
      sent: 0,
      failed: 0,
      queued: 0,
    };
  }

  /**
   * Add a message job to the queue
   */
  enqueue(type, payload) {
    const job = {
      id: uuidv4(),
      type,       // 'text' | 'image' | 'document'
      payload,
      status: 'pending',
      createdAt: new Date().toISOString(),
      attempts: 0,
    };
    this.queue.push(job);
    this.stats.queued++;
    this._processNext();
    return job;
  }

  getJob(id) {
    return this.queue.find((j) => j.id === id) || null;
  }

  getStats() {
    return {
      ...this.stats,
      pendingJobs: this.queue.filter((j) => j.status === 'pending').length,
      processingJobs: this.queue.filter((j) => j.status === 'processing').length,
    };
  }

  async _processNext() {
    if (this.processing) return;

    const pending = this.queue.filter((j) => j.status === 'pending');
    if (pending.length === 0) return;

    this.processing = true;
    const job = pending[0];
    job.status = 'processing';
    job.attempts++;

    try {
      let result;
      switch (job.type) {
        case 'text':
          result = await this.waClient.sendText(job.payload.to, job.payload.message);
          break;
        case 'image':
          result = await this.waClient.sendImage(
            job.payload.to,
            job.payload.imageUrl,
            job.payload.caption
          );
          break;
        case 'document':
          result = await this.waClient.sendDocument(
            job.payload.to,
            job.payload.fileUrl,
            job.payload.fileName,
            job.payload.mimetype
          );
          break;
        default:
          throw new Error(`Unknown job type: ${job.type}`);
      }

      job.status = 'sent';
      job.result = result;
      job.sentAt = new Date().toISOString();
      this.stats.sent++;
      this.stats.queued = Math.max(0, this.stats.queued - 1);
    } catch (err) {
      job.status = job.attempts >= 3 ? 'failed' : 'pending'; // retry up to 3x
      job.error = err.message;
      if (job.status === 'failed') {
        this.stats.failed++;
        this.stats.queued = Math.max(0, this.stats.queued - 1);
      }
    }

    // Throttle: wait before next message
    await new Promise((r) => setTimeout(r, this.intervalMs));
    this.processing = false;
    this._processNext();
  }
}

module.exports = MessageQueue;
