// src/middleware/auth.js
// Simple API key authentication

function apiKeyAuth(req, res, next) {
  const apiKey = process.env.API_KEY;

  // Skip auth if no API key configured (dev mode)
  if (!apiKey || apiKey === 'your-secret-api-key-here') {
    console.warn('⚠️  WARNING: Running without API key authentication. Set API_KEY in .env for production.');
    return next();
  }

  const provided =
    req.headers['x-api-key'] ||          // Header: X-Api-Key: xxx
    req.query.api_key ||                   // Query: ?api_key=xxx
    req.headers.authorization?.replace('Bearer ', ''); // Header: Authorization: Bearer xxx

  if (!provided || provided !== apiKey) {
    return res.status(401).json({
      ok: false,
      error: 'Unauthorized — provide a valid API key via X-Api-Key header',
    });
  }

  next();
}

module.exports = apiKeyAuth;
