// src/routes.js
// REST API endpoints for the WA Gateway

const express = require('express');
const QRCode = require('qrcode');

function createRouter(waClient, queue) {
  const router = express.Router();

  // ──────────────────────────────────────────────
  // Status & Health
  // ──────────────────────────────────────────────

  /** GET /status — connection status */
  router.get('/status', (req, res) => {
    res.json({ ok: true, ...waClient.getStatus() });
  });

  /** GET /health — simple liveness probe */
  router.get('/health', (req, res) => {
    res.json({ ok: true, uptime: process.uptime() });
  });

  /** GET /qr — get QR code as base64 PNG (for dashboard) */
  router.get('/qr', async (req, res) => {
    const raw = waClient.getQr();
    if (!raw) {
      return res.status(404).json({ ok: false, error: 'No QR code available. Already connected or not yet initialized.' });
    }
    try {
      const png = await QRCode.toDataURL(raw);
      res.json({ ok: true, qr: png });
    } catch (err) {
      res.status(500).json({ ok: false, error: 'Failed to generate QR image' });
    }
  });

  /** GET /qr/image — serve QR as actual PNG image */
  router.get('/qr/image', async (req, res) => {
    const raw = waClient.getQr();
    if (!raw) {
      return res.status(404).send('No QR available');
    }
    res.setHeader('Content-Type', 'image/png');
    QRCode.toFileStream(res, raw);
  });

  // ──────────────────────────────────────────────
  // Send Messages
  // ──────────────────────────────────────────────

  /**
   * POST /send/text
   * Body: { to: "6281234567890", message: "Hello!" }
   */
  router.post('/send/text', (req, res) => {
    const { to, message } = req.body;

    if (!to || !message) {
      return res.status(400).json({ ok: false, error: '`to` and `message` are required' });
    }
    if (typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({ ok: false, error: '`message` must be a non-empty string' });
    }

    const job = queue.enqueue('text', { to, message: message.trim() });
    res.status(202).json({ ok: true, jobId: job.id, status: job.status });
  });

  /**
   * POST /send/image
   * Body: { to: "6281234567890", imageUrl: "https://...", caption: "optional" }
   */
  router.post('/send/image', (req, res) => {
    const { to, imageUrl, caption = '' } = req.body;

    if (!to || !imageUrl) {
      return res.status(400).json({ ok: false, error: '`to` and `imageUrl` are required' });
    }

    const job = queue.enqueue('image', { to, imageUrl, caption });
    res.status(202).json({ ok: true, jobId: job.id, status: job.status });
  });

  /**
   * POST /send/document
   * Body: { to, fileUrl, fileName, mimetype }
   */
  router.post('/send/document', (req, res) => {
    const { to, fileUrl, fileName, mimetype = 'application/octet-stream' } = req.body;

    if (!to || !fileUrl || !fileName) {
      return res.status(400).json({ ok: false, error: '`to`, `fileUrl`, and `fileName` are required' });
    }

    const job = queue.enqueue('document', { to, fileUrl, fileName, mimetype });
    res.status(202).json({ ok: true, jobId: job.id, status: job.status });
  });

  /**
   * POST /send/bulk
   * Body: { recipients: ["628...", "628..."], message: "Hello!" }
   */
  router.post('/send/bulk', (req, res) => {
    const { recipients, message } = req.body;

    if (!Array.isArray(recipients) || recipients.length === 0) {
      return res.status(400).json({ ok: false, error: '`recipients` must be a non-empty array' });
    }
    if (!message) {
      return res.status(400).json({ ok: false, error: '`message` is required' });
    }
    if (recipients.length > 100) {
      return res.status(400).json({ ok: false, error: 'Max 100 recipients per bulk request' });
    }

    const jobs = recipients.map((to) =>
      queue.enqueue('text', { to, message })
    );

    res.status(202).json({
      ok: true,
      total: jobs.length,
      jobs: jobs.map((j) => ({ jobId: j.id, to: j.payload.to, status: j.status })),
    });
  });

  // ──────────────────────────────────────────────
  // Job Tracking
  // ──────────────────────────────────────────────

  /** GET /jobs/:id — check job status */
  router.get('/jobs/:id', (req, res) => {
    const job = queue.getJob(req.params.id);
    if (!job) {
      return res.status(404).json({ ok: false, error: 'Job not found' });
    }
    res.json({ ok: true, job });
  });

  /** GET /jobs/stats — queue statistics */
  router.get('/jobs/stats', (req, res) => {
    res.json({ ok: true, stats: queue.getStats() });
  });

  // ──────────────────────────────────────────────
  // Session Management
  // ──────────────────────────────────────────────

  /** POST /logout — disconnect and clear session */
  router.post('/logout', async (req, res) => {
    try {
      await waClient.logout();
      res.json({ ok: true, message: 'Logged out. Restart the server and scan QR again.' });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  return router;
}

module.exports = createRouter;
