# 🚀 Panduan Deploy WA Gateway di VPS Debian

Panduan ini untuk **Debian 11 (Bullseye)** atau **Debian 12 (Bookworm)**.
Estimasi waktu: **15–20 menit**.

---

## Persiapan Sebelum Mulai

Pastikan kamu punya:
- ✅ VPS Debian dengan IP publik (misal: `123.456.789.0`)
- ✅ Domain yang sudah diarahkan ke IP VPS (DNS A Record)
- ✅ Akses SSH ke VPS (username `root` atau user dengan `sudo`)
- ✅ File `wa-gateway.zip` sudah didownload

> **Cara cek DNS sudah mengarah ke VPS:**
> Buka https://dnschecker.org → masukkan domain kamu → pastikan IP-nya sama dengan IP VPS

---

## Langkah 1 — Masuk ke VPS via SSH

Di komputer lokalmu, buka Terminal (Mac/Linux) atau PowerShell/PuTTY (Windows):

```bash
ssh root@123.456.789.0
```

Ganti `123.456.789.0` dengan IP VPS kamu. Masukkan password jika diminta.

---

## Langkah 2 — Update Sistem

```bash
apt update && apt upgrade -y
```

Tunggu hingga selesai (1–3 menit).

---

## Langkah 3 — Install Node.js 20

```bash
# Tambah repository Node.js resmi
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -

# Install Node.js
apt install -y nodejs

# Verifikasi
node -v    # harus muncul v20.x.x
npm -v     # harus muncul 10.x.x
```

---

## Langkah 4 — Install Nginx & Certbot

```bash
apt install -y nginx certbot python3-certbot-nginx unzip
```

Aktifkan Nginx:
```bash
systemctl enable nginx
systemctl start nginx
```

Cek berjalan:
```bash
systemctl status nginx
# harus muncul: Active: active (running)
```

---

## Langkah 5 — Upload & Extract Aplikasi

### Dari komputer lokal, upload file zip ke VPS:

**Mac/Linux:**
```bash
scp /path/to/wa-gateway.zip root@123.456.789.0:/var/www/
```

**Windows (PowerShell):**
```powershell
scp C:\Users\Kamu\Downloads\wa-gateway.zip root@123.456.789.0:/var/www/
```

**Atau lewat panel VPS** (FileManager / SFTP dengan WinSCP/FileZilla):
- Host: IP VPS
- Port: 22
- Username: root
- Upload ke folder `/var/www/`

### Lalu di VPS, extract:
```bash
cd /var/www
unzip wa-gateway.zip
mv wa-gateway wa-gw   # opsional, biar nama folder lebih pendek
cd wa-gw
```

---

## Langkah 6 — Konfigurasi Environment

```bash
cp .env.example .env
nano .env
```

Edit isinya:
```
PORT=3000
HOST=0.0.0.0

# Ganti dengan API key yang kuat (wajib untuk keamanan!)
API_KEY=isi-dengan-password-rahasia-kamu

RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_REQUESTS=100

QUEUE_CONCURRENCY=5
QUEUE_INTERVAL_MS=1000

SESSION_DIR=./sessions
LOG_LEVEL=info
```

Simpan: tekan `Ctrl+X` → `Y` → `Enter`

> **Tips generate API key acak:**
> ```bash
> openssl rand -hex 32
> ```
> Copy hasilnya, paste sebagai nilai `API_KEY`

---

## Langkah 7 — Install Dependencies Node.js

```bash
npm install --omit=dev
```

Tunggu hingga selesai (~1–2 menit).

---

## Langkah 8 — Test Jalankan Aplikasi

Coba jalankan dulu secara manual untuk memastikan tidak ada error:

```bash
node src/index.js
```

Jika berhasil, akan muncul:
```
🚀 Starting WA Gateway...
📡 WA Gateway running at http://0.0.0.0:3000
```

Stop dengan `Ctrl+C`, lanjut ke langkah berikutnya.

Jika ada error, cek apakah semua file terupload dengan benar.

---

## Langkah 9 — Setup Systemd Service (Auto-Start)

Buat service file agar app otomatis jalan saat VPS reboot:

```bash
nano /etc/systemd/system/wa-gateway.service
```

Isi dengan (sesuaikan path jika nama foldermu berbeda):
```ini
[Unit]
Description=WhatsApp API Gateway
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/var/www/wa-gw
ExecStart=/usr/bin/node src/index.js
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=wa-gateway
EnvironmentFile=/var/www/wa-gw/.env

[Install]
WantedBy=multi-user.target
```

Simpan: `Ctrl+X` → `Y` → `Enter`

Aktifkan dan jalankan:
```bash
systemctl daemon-reload
systemctl enable wa-gateway
systemctl start wa-gateway
```

Cek statusnya:
```bash
systemctl status wa-gateway
```

Harus muncul **Active: active (running)** ✅

---

## Langkah 10 — Konfigurasi Nginx

```bash
nano /etc/nginx/sites-available/wa-gateway
```

Isi dengan (ganti `yourdomain.com` dengan domain kamu):
```nginx
server {
    listen 80;
    listen [::]:80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass         http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_set_header   Upgrade           $http_upgrade;
        proxy_set_header   Connection        "upgrade";
        proxy_read_timeout 120s;
        client_max_body_size 10M;
    }
}
```

Simpan, lalu aktifkan:
```bash
# Aktifkan site
ln -s /etc/nginx/sites-available/wa-gateway /etc/nginx/sites-enabled/

# Nonaktifkan site default
rm -f /etc/nginx/sites-enabled/default

# Test konfigurasi
nginx -t
# harus muncul: syntax is ok / test is successful

# Reload Nginx
systemctl reload nginx
```

Pada tahap ini, `http://yourdomain.com` sudah bisa diakses (tanpa HTTPS).

---

## Langkah 11 — Install SSL (HTTPS Gratis)

```bash
certbot --nginx -d yourdomain.com -d www.yourdomain.com --email email@kamu.com --agree-tos --non-interactive --redirect
```

Ganti:
- `yourdomain.com` → domain kamu
- `email@kamu.com` → email kamu (untuk notifikasi perpanjangan)

Jika berhasil:
```
Successfully received certificate.
...
Congratulations! You have successfully enabled HTTPS
```

SSL akan **auto-renew otomatis** setiap 90 hari via cron Certbot.

---

## Langkah 12 — Buka Firewall (jika aktif)

```bash
# Cek apakah ufw aktif
ufw status

# Jika aktif, izinkan port yang diperlukan
ufw allow ssh
ufw allow 'Nginx Full'

# Port 3000 TIDAK perlu dibuka ke publik (diakses internal oleh Nginx)
```

---

## Langkah 13 — Login WhatsApp

Buka browser, akses:
```
https://yourdomain.com
```

Dashboard akan tampil dengan QR code. Scan menggunakan WhatsApp:
1. Buka WhatsApp di HP
2. Ketuk ⋮ → **Perangkat Tertaut** → **Tautkan Perangkat**
3. Scan QR code di dashboard

Setelah berhasil, status berubah menjadi **CONNECTED** ✅

---

## Langkah 14 — Test Kirim Pesan

```bash
curl -X POST https://yourdomain.com/api/send/text \
  -H "Content-Type: application/json" \
  -H "X-Api-Key: API_KEY_KAMU" \
  -d '{"to":"6281234567890","message":"Test dari WA Gateway! 🎉"}'
```

Respons sukses:
```json
{
  "ok": true,
  "jobId": "uuid-xxx",
  "status": "pending"
}
```

---

## Perintah Berguna Sehari-hari

```bash
# Lihat log live
journalctl -u wa-gateway -f

# Restart aplikasi
systemctl restart wa-gateway

# Cek status
systemctl status wa-gateway

# Lihat log Nginx
tail -f /var/log/nginx/error.log

# Restart Nginx
systemctl restart nginx

# Perbarui aplikasi (setelah upload file baru)
cd /var/www/wa-gw
npm install --omit=dev
systemctl restart wa-gateway
```

---

## Troubleshooting

**QR tidak muncul / dashboard tidak bisa diakses:**
```bash
systemctl status wa-gateway        # cek apakah app jalan
journalctl -u wa-gateway -n 50     # lihat error log
```

**502 Bad Gateway di browser:**
```bash
# App belum jalan atau crash
systemctl restart wa-gateway
journalctl -u wa-gateway -n 20
```

**SSL gagal (certbot error):**
- Pastikan DNS domain sudah mengarah ke IP VPS
- Pastikan port 80 terbuka di firewall VPS/provider

**WhatsApp terputus setelah beberapa hari:**
- Normal terjadi, app akan auto-reconnect
- Jika tidak bisa reconnect, buka dashboard dan scan QR lagi
- Jika QR tidak muncul: `rm -rf /var/www/wa-gw/sessions && systemctl restart wa-gateway`

---

## Ringkasan Arsitektur

```
Internet
   │
   ▼
Nginx (port 443/80)          ← domain kamu
   │  reverse proxy
   ▼
Node.js / WA Gateway         ← port 3000 (internal)
   │
   ▼
WhatsApp servers             ← via Baileys WebSocket
```
