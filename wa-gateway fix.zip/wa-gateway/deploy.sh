#!/bin/bash
# deploy.sh — Setup otomatis WA Gateway di VPS Ubuntu/Debian
# Jalankan sebagai root: bash deploy.sh yourdomain.com your@email.com

set -e

DOMAIN=${1:?"Usage: bash deploy.sh <domain> <email>"}
EMAIL=${2:?"Usage: bash deploy.sh <domain> <email>"}
APP_DIR="/var/www/wa-gateway"

echo ""
echo "========================================"
echo "  WA Gateway — Auto Deploy"
echo "  Domain : $DOMAIN"
echo "  Email  : $EMAIL"
echo "========================================"
echo ""

# ── 1. Update sistem & install dependencies ──────────────────────────────────
echo "[1/6] Installing system packages..."
apt-get update -qq
apt-get install -y -qq nginx certbot python3-certbot-nginx curl

# Install Node.js 20 (LTS)
if ! command -v node &> /dev/null; then
    echo "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y -qq nodejs
fi
echo "    Node.js $(node -v), npm $(npm -v)"

# ── 2. Deploy app files ──────────────────────────────────────────────────────
echo "[2/6] Deploying app to $APP_DIR..."
mkdir -p "$APP_DIR"

# Copy files (jalankan dari folder wa-gateway)
cp -r . "$APP_DIR/"
chown -R www-data:www-data "$APP_DIR"

cd "$APP_DIR"

# Setup .env jika belum ada
if [ ! -f .env ]; then
    cp .env.example .env
    # Generate random API key
    API_KEY=$(openssl rand -hex 32)
    sed -i "s/your-secret-api-key-here/$API_KEY/" .env
    echo ""
    echo "  ✅ API Key generated: $API_KEY"
    echo "  ⚠️  Simpan API key ini! Tidak bisa dilihat lagi."
    echo ""
fi

# Install npm packages
echo "    Installing npm packages..."
npm ci --omit=dev --silent

# ── 3. Systemd service ───────────────────────────────────────────────────────
echo "[3/6] Setting up systemd service..."
cp wa-gateway.service /etc/systemd/system/wa-gateway.service

# Update path di service file
sed -i "s|/var/www/wa-gateway|$APP_DIR|g" /etc/systemd/system/wa-gateway.service

systemctl daemon-reload
systemctl enable wa-gateway
systemctl restart wa-gateway

sleep 2
if systemctl is-active --quiet wa-gateway; then
    echo "    ✅ Service is running"
else
    echo "    ❌ Service failed to start. Check: journalctl -u wa-gateway -n 50"
    exit 1
fi

# ── 4. Nginx config ──────────────────────────────────────────────────────────
echo "[4/6] Configuring Nginx..."
cp nginx.conf /etc/nginx/sites-available/wa-gateway

# Ganti domain placeholder
sed -i "s/yourdomain.com/$DOMAIN/g" /etc/nginx/sites-available/wa-gateway

# Aktifkan site
ln -sf /etc/nginx/sites-available/wa-gateway /etc/nginx/sites-enabled/wa-gateway
rm -f /etc/nginx/sites-enabled/default

# Test & reload nginx (tanpa SSL dulu)
# Sementara pakai HTTP-only untuk certbot
cat > /etc/nginx/sites-available/wa-gateway-temp << EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host \$host;
    }
}
EOF
ln -sf /etc/nginx/sites-available/wa-gateway-temp /etc/nginx/sites-enabled/wa-gateway
nginx -t && systemctl reload nginx
echo "    ✅ Nginx configured (HTTP)"

# ── 5. SSL dengan Let's Encrypt ──────────────────────────────────────────────
echo "[5/6] Getting SSL certificate for $DOMAIN..."
certbot --nginx \
    -d "$DOMAIN" \
    -d "www.$DOMAIN" \
    --email "$EMAIL" \
    --agree-tos \
    --non-interactive \
    --redirect

# Pasang config Nginx final (dengan SSL)
cp nginx.conf /etc/nginx/sites-available/wa-gateway
sed -i "s/yourdomain.com/$DOMAIN/g" /etc/nginx/sites-available/wa-gateway
ln -sf /etc/nginx/sites-available/wa-gateway /etc/nginx/sites-enabled/wa-gateway
rm -f /etc/nginx/sites-available/wa-gateway-temp

nginx -t && systemctl reload nginx
echo "    ✅ SSL installed, HTTPS active"

# Auto-renew SSL (Certbot sudah tambah cron, ini backup)
echo "0 3 * * * root certbot renew --quiet" >> /etc/cron.d/certbot-renew

# ── 6. Summary ───────────────────────────────────────────────────────────────
echo ""
echo "========================================"
echo "  ✅ DEPLOY SELESAI!"
echo "========================================"
echo ""
echo "  Dashboard  : https://$DOMAIN"
echo "  API base   : https://$DOMAIN/api"
echo ""
echo "  API Key    : $(grep API_KEY $APP_DIR/.env | cut -d= -f2)"
echo ""
echo "  Perintah berguna:"
echo "    systemctl status wa-gateway     # cek status"
echo "    journalctl -u wa-gateway -f     # lihat log live"
echo "    systemctl restart wa-gateway    # restart app"
echo ""
echo "  Langkah selanjutnya:"
echo "    1. Buka https://$DOMAIN"
echo "    2. Scan QR code dengan WhatsApp"
echo "    3. Mulai kirim pesan via API!"
echo ""
